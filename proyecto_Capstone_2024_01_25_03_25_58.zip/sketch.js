var bird, birdImg;
var obstacle1;
var backgroundImg, path;
var score=0;

function preload() {
 birdImg = loadImage("flappy bird.png");
backgroundImg = loadImage('flappy.png');
  gameOverImg = loadImage("game over.png");
}
function setup() {
  createCanvas(400, 400);

  path = createSprite(200,200,200,200);
  path.addImage(backgroundImg);
path.velocityX = -5;
  path.scale = 0.5;

  edges = createEdgeSprites();
  
  bird = createSprite(50,200,50,50);
  bird.addImage(birdImg);
  bird.scale = 0.10;
  
  gameOver = createSprite(200,200);
  gameOver.addImage(gameOverImg);
  
  gameState = 1;
  gameOver.visible = false;
  
  score = 0;
  
  gameOver.scale = 0.3;
   obstaclesGroup = new Group();
}

function draw() {
  background(0);
  fill(0);
  text("Puntuación: "+ score, 20,20);
  
  obstaclesGroup.depth = gameOver.depth;
    gameOver.depth = gameOver.depth + 1;
  if(keyDown("space") && bird.y >= 109) {
      bird.velocityY = -4;
    }
  
    bird.velocityY = bird.velocityY + 0.4
  
  
  
  bird.collide(edges);
  
  if (gameState === 1) {
     spawnObstacles()
  spawnObstacles2();
  }
  
  if (obstaclesGroup.isTouching(bird)) {
      gameState = 0;
      }
  else if (gameState === 0) {
    
  gameOver.visible = true;
    
    path.velocityX = 0;
    bird.velocityY = 0;
    
    //establece ciclo de vida a los objetos del juego para que nunca puedan ser destruidos
    obstaclesGroup.setLifetimeEach(-1);
    
    obstacle1.velocityX = 0;
    obstacle2.velocityX = 0;
    
    
    
  }
  
  if(path.x < 0 ){
    path.x = width/2;
  }
 
  drawSprites();
}

function spawnObstacles() {
  //escribe aquí el código para apareer las nubes
  if (frameCount % 80 === 0) {
   obstacle1 = createSprite(400,300, 60,300);
    obstacle1.y = Math.round(random(400,300));
    
    obstacle1.velocityX = -3;
   
     //asigna ciclo de vida a la variable
    obstacle1.lifetime = 300;
    
    

    
  }
  
}

function spawnObstacles2() {
  //escribe aquí el código para apareer las nubes
  if (frameCount % 80 === 0) {
   obstacle2 = createSprite(400,300, 60,90);
    obstacle2.y = Math.round(random(50,0));
    obstacle2.shapeColor = ('green');
    obstacle1.shapeColor = ('green');
    
    obstacle2.velocityX = -3;
    
     //asigna ciclo de vida a la variable
    obstacle2.lifetime = 300;
    
    
obstaclesGroup.add(obstacle1);
    obstaclesGroup.add(obstacle2);
    
  }
  
}

