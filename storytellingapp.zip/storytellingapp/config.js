// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const firebaseConfig = {
  apiKey: 'AIzaSyDa3_Bv77FRDoW-P95uVI1sISo5JdM69bY',
  authDomain: 'hotel-chatbot-demo.firebaseapp.com',
  databaseURL: 'https://hotel-chatbot-demo-default-rtdb.firebaseio.com',
  projectId: 'hotel-chatbot-demo',
  storageBucket: 'hotel-chatbot-demo.appspot.com',
  messagingSenderId: '1092137861522',
  appId: '1:1092137861522:web:025039ed5ee2809e17814b',
  measurementId: 'G-V8HVEEE1SY',
};